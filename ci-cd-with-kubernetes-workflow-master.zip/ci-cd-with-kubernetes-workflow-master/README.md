## CI CD workflow with kubernetes
![](https://github.com/tprakash17/CI-CD-with-kubernetes/blob/master/ci%20cd%20%20with%20kubernetes.png)
